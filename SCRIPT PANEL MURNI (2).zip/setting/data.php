<?php 
$nik = "𝙒𝙀𝘽 || 𝘼𝙆𝘽𝘼𝙍𝙕 𝙉𝙎";
$sender = "admin@akbarz.ceo.id";
?>